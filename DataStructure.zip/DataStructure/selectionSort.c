

#include<stdio.h>

/*void sortingOptions(){

        printf("\033[0;33m");
        printf("\n1.Bubble Sort\t2.Selection Sort\n\n");
        printf("\033[0;0m");
}*/

void selectionSort(){

        int size = 0;

        printf("\nEnter size of array : ");
        scanf("%d",&size);

        int arr[size];

        printf("Enter %d element : ",size);
        for(int i=0;i<size;i++)
                scanf("%d",&arr[i]);

        int len = sizeof(arr)/sizeof(arr[0]) ;          

        printf("\033[03;37m");
        printf("\n\nArray Before Sorting :\t | ");
        for(int i=0; i<len; i++)
                printf("%d | ",arr[i]);
        printf("\n");

        // int count =0;

        for(int i=0; i<len; i++){
		//int dataMovedCnt = 0;
		for(int j=i+1;j<len; j++){

			if(arr[i] > arr[j]){
				int temp = arr[j];
				arr[j]   = arr[i];
				arr[i]    = temp;

		//		dataMovedCnt = 1;
			}
		}
		//if(dataMovedCnt == 0)		jevha 14 32 65 78 91 asa data yto tvha gndt. bcoz 14 first pos lach rahnare mg asha veli ekhi data move hot nahi.
		//	break;
	}


        printf("\n\nArray after Sorting :\t | ");
        for(int i=0; i<len; i++)
                printf("%d | ",arr[i]);
        //printf("\n\n%d\n",count);
        printf("\n\n\n");
        printf("\033[0;0m");
}
void main(){
	selectionSort();
}
