
#include<stdio.h>
#include<stdlib.h>

/*struct Node {
	int data ;
	struct Node* next;
};*/
struct Node* front = NULL ;
struct Node* rear  = NULL ;
int flag = 0 ;

void queueOptions(){
	printf("\033[0;33m");
	printf("\t1.printQueue\t2.Enqueue\t3.Dequeue\n\t4.isEmpty\t5.exit\n\n");
	printf("\033[0;0m");
}

/*struct Node* createNode(){
	
	struct Node* newNode = (struct Node*) malloc(sizeof(struct Node));

	printf("Enter Data : ");
	scanf("%d",&newNode->data);
	
	newNode->next = NULL;

	return newNode;
}*/

void printQueue(){

	if(rear == NULL || front == NULL){
		printf("\033[0;31m");
		printf("\t--> Queue is empty <--\n");
		printf("\033[0;0m");
	} else {
		struct Node* temp = front;
		
		printf("\033[5;37m");
		printf("\n\nQueue : \t| ");

		while(temp != NULL){
			if(temp->next == NULL)
				printf("%d",temp->data);
			else
				printf("%d",temp->data);

			printf(" | ");
			temp = temp->next;
		}
		printf("\033[0;0m\n");
		printf("\n");
	}
}

void enqueue(){

	struct Node* newNode = createNode();

	if(front == NULL){
		front = newNode;
		rear  = newNode;
	}else{

		rear->next = newNode;
		rear = newNode;
	}

	printQueue();
}

int dequeue() {
	
	struct Node* temp = front;
	int retValue = front->data ;

	front = front->next;
	free(temp);

	return retValue;
}
int isEmptyQueue(){
	if(front != NULL)
		return 1;
	else
		return 0;
}

void queue () {
	printf("\033[04;37m");
	printf("\n\t\t---> ENTER YOUR CHOICE IN QUEUE <--\n\n");
        printf("\033[0;0m");

	do {
		printf("\n--------------------------------------------------------------\n\n");
		queueOptions();

		int choice = 0;
		//int flag = 0 ;

                printf("\n--> Enter Choice : ");
                scanf("%d",&choice);

		if(choice == 1)
			printQueue();
		else if (choice == 2)
			enqueue();
		else if (choice == 3){
			if(front == NULL){
				printf("\033[0;31m");
 		               printf("\t--> Queue is Empty <--\n");
			       printf("\033[0;0m");
			} else {
				printf("\033[4;37m");
				printf("\nRemoved element : %d\n\n",dequeue());
				printf("\033[0;0m\n");
				printQueue();
			}
		}else if (choice == 4){
			if(isEmptyQueue() == 1){
				printf("\n\t--> Queue is not Empty <--\n");
			} else {
				printf("\n\t--> Queue is Empty <--\n");
			}
		} else if (choice == 5){
			flag = 1;
		}else
			printf("\t\t--> Enter correct choice <--\n");
			
	} while(!flag);

	printf("\t --> thanks for using Queue <--\n\n");
}
/*
void main(){
	queue();
}*/
