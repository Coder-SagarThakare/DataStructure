
#include<stdio.h>
#include<stdlib.h>

/*struct Node {
	int  data;
	struct Node* next ;
};*/
//struct Node* head = NULL;
struct Node* tail = NULL;

void cllOptions(){

        printf("\n1.print Node\t2.add Node at End\t3.add Node at begining\t4.add Node at position\n");
        printf("5.deleteFirst\t6.deleteLast\t\t7.deleteAtPos\t\t8.delete All Nodes\t\n");
        printf("9.Count\t\t10.exit\t\n\n\n--> ");
}

struct Node* cllNewNode (){
	struct Node* node = (struct Node* ) malloc(sizeof(struct Node));

	printf("Enter Data -> ");
        scanf("%d",&node->data);

	node->next = NULL;

	return node;
}

void cllPrintNode(){
	if(head == NULL)
		printf("\t-->\tYour Circular LinkedList is Empty\t<--");
	else{
		struct Node* temp = head;
		printf("\nNode : ");
		do{
			if(temp->next == head)
				printf("|%d|",temp->data);
			else
				printf("|%d|-->",temp->data);
			temp = temp->next;

		} while(temp != head);
	}
}

void cllAddAtBeg(){
	struct Node* newNode =cllNewNode(); 

	if(head == NULL){
		head = newNode;
		tail = head;
		head->next = head;
	} else{
		newNode->next = head;
		head = newNode;
		tail->next = head;
	}

	cllPrintNode();
}

void cllAddAtEnd(){
	if(head == NULL)
		cllAddAtBeg();
	else {
		struct Node* newNode = cllNewNode();
		
		tail->next = newNode;
		tail = newNode;
		tail->next = head;

		cllPrintNode();
	}
}

int cllCount(){
	int cnt = 0;

	if(head == NULL)
		return 0;

	struct Node* temp = head;

	do{
		cnt++;
		temp = temp->next;
	}while(temp != head);

	return cnt;
}

void cllAddAtPos(){
	int pos=0; 

	printf("Enter position : ");
	scanf("%d",&pos);

	if(pos <= 0)
		printf("\t-->\tOur linkedList start from 1\t<--");
	else if (pos == 1)
		cllAddAtBeg();
	else if (pos>1 && pos<=cllCount()){
		int cnt=0;
		struct Node* temp    = head;
		struct Node* newNode = cllNewNode();

		while (cnt != pos-2){
			cnt++;
			temp = temp->next;
		}
		newNode->next = temp->next;
		temp->next = newNode;

		cllPrintNode();

	}else if (pos == (cllCount()+1)){
		cllAddAtEnd();
	}else if(pos > cllCount()){
		
		printf("\t-->\tEntered position is out of range\t<--");
	}
}
void cllDeleteFirst (){
	if(head == NULL){
		printf("\t-->\tNode Not Present\t<--");
		return;
	}else {
		struct Node* temp =head;

		head = temp->next;
		free(temp);
		tail->next = head;

		if(cllCount() == 1 && head==tail && temp==head){
			head = NULL;
			tail = NULL;

			printf("\t-->\tYour Circular LinkedList is Empty Now\t<--");
			return;
		}
		cllPrintNode();
	}
}
void cllDeleteLast (){
	if(head == NULL){
		printf("\t-->\tNode Not Present\t<--");
		return;
	}
	struct Node* temp = head;

	while (temp->next != tail)
		temp = temp->next;
	tail = temp;
	temp = temp->next;
	free(temp);
	tail->next = head;
	
	if(cllCount() == 1 && temp==head && head==tail){
                        head = NULL;
                        tail = NULL;
                        printf("\t-->\tYour Circular LinkedList is Empty Now\t<--");
                        return;
        }
	cllPrintNode();
}
void cllDeleteAtPos(){
	int pos=0;
	printf("Enter position : ");
	scanf("%d",&pos);

	if(pos<=0)
		printf("\t-->\tOur CircularLinkedList start form 1\t<--");
	else if (pos==1)
		cllDeleteFirst();
	else if(pos>1 && pos<cllCount()){
		struct Node* temp = head;
		struct Node* dummy = NULL;
		int cnt=0;

		while(cnt != pos-2){
			temp = temp->next;
			cnt++;
		}
		
		dummy = temp->next;
		temp->next = temp->next->next;

		cllPrintNode();
	}else if(pos == cllCount())
		cllDeleteLast();
	else if(pos > cllCount())
		printf("\t-->\tEntered position is out of range\t-->");
}
void cllDeleteAllNodes(){
	struct Node* temp = head;

	if(head == NULL){
		printf("\t-->\tLinkedList is already Empty\t<--");
		return;
	}

	do{
		head = head->next;
		free(temp);
		temp=head;

	}while(head != tail);

	free(head);

	head=NULL;
	tail=head;

	printf("\t-->Deleted All nodes from Circular LinkedList\t<--");
}
void circularSinglyLinkedList(){


        printf("\n\t\t\t-----> ENTER YOUR CHOICE <-----\n");
        int choice = 0, exit = 1;

        do{
		printf("\n\n");
                cllOptions();
                scanf("%d",&choice);

                switch(choice){
                        case 1 : cllPrintNode();
                                 break;
                        case 2 : cllAddAtEnd();
                                 break;
                        case 3 : cllAddAtBeg();
                                 break;
                        case 4 : cllAddAtPos();
                                 break;
                        case 5 : cllDeleteFirst();
                                 break;
                        case 6 : cllDeleteLast();
                                 break;
                        case 7 : cllDeleteAtPos();
                                 break;
                        case 8 : cllDeleteAllNodes();
                                 break;
			case 9: printf("Count : %d",cllCount());
                                break;
                        case 10 :exit = 0;
                                 break;
			default :printf("--> Enter perfect No  <--\n");
				 break;
                }
        }while(exit);

        printf("out of switch\n");
}
/*
void main(){
	
	circularSinglyLinkedList();
}*/
