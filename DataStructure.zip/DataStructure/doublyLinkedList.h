
//#include<stdio.h>
//#include<stdlib.h>
int chkInt(char*);
extern int error ;

struct NodeD {

	struct NodeD* prev;
	int data;
	struct NodeD* next;
};
struct NodeD* headD = NULL;


/*void options(){

        printf("\n\n1.print Node\t2.add Node at Beginning\t3.add Node at End\t4.add Node at position\n");
        printf("5.deleteFirst\t6.deleteLast\t\t7.deleteAtPos\t\t8.delete All Nodes\t\n");
        printf("9.Count\t\t10.exit\t\n\n\n--> ");
}*/
struct NodeD* dllCreateNewNode(){
	struct NodeD* node =(struct NodeD*) malloc(sizeof(struct NodeD));
	int data =0;
        char name[10];

	node->prev = NULL;

	//printf(" Enter Data -> ");
	//scanf("%d",&node->data);
        do{
                printf("Enter Data -> ");
                scanf("%s",name);

                node->data = chkInt(name);
        } while( error == 1);

	node->next = NULL;

	return node;
}
void dllPrintNode (){
	printf("\n");

	if(headD == NULL){
		printf("\033[0;31m");
		printf("\t--> Doubly Linked List is Empty <--");
		printf("\033[0;0m\n");
		return;
	}

	printf("Node : ");
	struct NodeD* temp = headD;

	printf("\033[5;37m");
	while(temp != NULL){
		if(temp->next != NULL)
			printf("|%d|-->",temp->data);
		else
			printf("|%d|",temp->data);
		temp = temp->next;
	}
	printf("\033[0;0m\n");
}

void dllAddAtBeg(){
	struct NodeD* newNode = dllCreateNewNode();
	
	if(headD == NULL){
		headD = newNode;
	}else {

		struct NodeD* temp = headD;

		newNode->next = headD;
		headD->prev = newNode;
		headD = newNode;
	}
	dllPrintNode();
}

void dllAddAtEnd(){
	if(headD == NULL)
		dllAddAtBeg();
	else {
		struct NodeD* temp = headD;
		struct NodeD* newNode = dllCreateNewNode();

		while(temp->next != NULL){
			temp = temp->next;
		}
		
		temp->next = newNode;
		newNode->prev = temp;

		dllPrintNode();
	}
}

int dllCount(){
	struct NodeD * temp = headD;
	int cnt=0;

	while(temp != NULL){
		cnt++;
		temp = temp->next;
	}
	return cnt;
}

void dllAddAtPos(){
	int pos =0;

	//printf("Enter position : ");
	//scanf("%d",&pos);
        char name[10];

        do{
                printf("Enter pos : ");
                scanf("%s",name);

                pos = chkInt(name);
        } while(error == 1);

	
	if(pos <= 0){
		printf("\033[0;31m");
		printf("\t--> Our Doubly Linked List Start From 1 <--");
		printf("\033[0;0m");
	}else if(pos ==1)
		dllAddAtBeg();
	else if (pos>1 && pos<=dllCount()){
		struct NodeD* temp = headD;
		struct NodeD* newNode = dllCreateNewNode();
		int cnt =0;

		while(cnt != pos-2){
			cnt++;
			temp = temp->next;
		}

		newNode->prev = temp;
		newNode->next = temp->next;
		temp->next->prev = newNode;
		temp->next = newNode;

		dllPrintNode();
	}else if (pos == (dllCount()+1))
		dllAddAtEnd();
	else {
		printf("\033[0;31m");
		printf("\t--> Entered position is out of range <--");
		printf("\033[0;0m");
	}
	printf("\n");
}

void dllDeleteFirst(){

	if(headD == NULL){
		printf("\033[0;31m");
		printf("\t--> Doubly LinkedList is Already Empty <--\n");
		printf("\033[0;0m");
	}else {
		struct NodeD* temp = headD;
		headD = headD->next;
		free(temp);

		if(headD != NULL){
			headD->prev = NULL;
			dllPrintNode();
		}else 
			printf("\t\t--> Doubly LinkedList is Now Empty <--\n");
	
	}
}
void dllDeleteLast(){
	if (headD == NULL){
		printf("\033[0;31m");
		printf("\t--> Doubly LInkedList is already Empty <--");
		printf("\033[0;0m");
	}
	else{
		if(headD ->next == NULL){
			free(headD);
			headD = NULL;
			printf("\t--> Doubly LinkedList is Now Empty <--");
		} else {
			struct NodeD* temp = headD;

			while(temp->next->next != NULL)
				temp = temp->next;
	
				free(temp->next);
				temp->next = NULL;

				dllPrintNode();
		}
	}
	printf("\n");
}
void dllDeleteAtPos(){
	int pos=0;

	        char name[10];

        do{
                printf("Enter pos : ");
                scanf("%s",name);

                pos = chkInt(name);
        } while(error == 1);


	if(pos <= 0){
		printf("\033[0;31m");
		printf("\t--> Our Doubly Linkedlist start from 1 <--\n");
		printf("\033[0;0m");
	}else if(pos ==1 )
		dllDeleteFirst();
	else if(pos >1 && pos<dllCount()){
		struct NodeD* temp = headD;

		int cnt=0;

		while(cnt != pos-2){
			cnt++;
			temp = temp->next;
		}

		struct NodeD* dummy = temp->next;

		temp->next = temp->next->next;
		temp->next->prev = temp;

		free(dummy);

		dllPrintNode();
	}else if (pos == dllCount())
		dllDeleteLast();
	else{
		printf("\033[0;31m");
		printf("\t--> Entered position is out of range <--\n");
		printf("\033[0;0m");
	}

}
void dllDeleteAllNodes(){
	struct NodeD* temp = headD;

	if(headD == NULL){
		printf("\033[0;31m");
		printf("\t--> Your Doubly LinkedList is already empty <--\n");
		printf("\033[0;0m");
		return;
	}
	while(headD != NULL){
		headD = headD->next;
		free(temp);
		temp = headD;
	}
	printf("\t--> Your Doubly LinkedList is Empty Now <--\n");
}

void doublyLinkedList(){

	headD = NULL;

	printf("\033[04;37m");
        printf("\n\t\t\t-----> ENTER YOUR CHOICE IN DOUBLY LINKEDLIST <-----\n\n");
	printf("\033[0;37m");
        int choice = 0, exit = 1;

	do{
                options();
                //scanf("%d",&choice);
                char name[10];
	
		do{
                        printf("Enter choice --> ");
                        scanf("%s",name);

                         choice= chkInt(name);
                } while(error == 1);


                switch(choice){
                        case 1 : dllPrintNode();
                                 break;
                        case 2 : dllAddAtEnd();
                                 break;
                        case 3 : dllAddAtBeg();
                                 break;
                        case 4 : dllAddAtPos();
                                 break;
                        case 5 : dllDeleteFirst();
                                 break;
                        case 6 : dllDeleteLast();
                                 break;
                        case 7 : dllDeleteAtPos();
                                 break;
			case 9: printf("Count of Nodes : %d\n",dllCount());
                                break;
                        case 8 : dllDeleteAllNodes();
                                 break;
                        case 10 :
                                exit = 0;
                                 break;
                        default :
				printf("\033[0;31m");
				printf("\t--> Enter perfect No <--\n");
				printf("\033[0;0m");
				break;

			//printf("\n");
                }
        }while(exit);
 
        printf("\n\t-->\tThanks for using Doubly Linked List DATA STRUCTURE\t<--\n");
}
/*
void main(){
	doublyLinkedList();
}*/
