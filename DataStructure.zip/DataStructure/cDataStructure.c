
#include<stdio.h>
#include<stdlib.h>

#include  "myDS.h"

/*
#include "singlyLinkedList.h"
#include "circularSinglyLinkedList.h"
#include "doublyLinkedList.h"
#include "doublyCircularLinkedList.h"
#include "stack.h"
#include "queue.h"
#include "bubbleSort.h"
#include "selectionSort.h"
#include "insertionSort.h"
*/

extern int error;
int converteInInt(char*);
int chkInt(char*);



void main(){

	printf("\033[1;37m");
	printf("\n\n\t\t----> WELCOME TO WORLD OF DATA STRUCTURE <----\n\n");
	printf("\033[0;0m");

	int exitFromDS = 0;

	do{


		printf("----------------------------------------------------------------------------\n\n");
	printf("\033[3;36m");
	printf("1. Linked List\n");
	printf("2. Stack\n");
	printf("3. Queue\n");	
	printf("4. Sorting Algorithms\n");	
	printf("5. Exit\n\n");	
	printf("\033[1;00m");


	int choice = 0;
        char name[10];

        do{

		printf("Enter your choice : ");
                scanf("%s",name);

                choice = chkInt(name);
        } while(error == 1);

	//scanf("%d",&choice);

		printf("\n");
	switch (choice){

		case 1 : {

			
				 int option = 0;
			do{
				llOptions();

 			 	//printf("Enter your choice : ");
				int choiceLL = 0;					
				//scanf("%d",&choiceLL);
				        char name[10];

				        do{

				                printf("Enter your choice : ");
				                scanf("%s",name);

				                choiceLL = chkInt(name);
				        } while(error == 1);

				option = choiceLL;

				switch(choiceLL){
					case 1 : singlyLinkedList();
						 break;

					case 2 : doublyLinkedList();
						 break;

					case 3 : circularSinglyLinkedList();
						 break;

					case 4 : doublyCircularLinkedList();
						 break;

					case 5 : break;

					default :
						printf("\033[0;31m");
						printf("\t--> Please Enter proper Choice <--\n");
						printf("\033[0;0m");
						break;
				}

			 }while(option != 5);
		
		}
			 break;
		case 2 :
			// printf("in stack\n");
			stack();
			break;
		case 3 : queue();
			 break;
		case 4 :{

                                 int option = 0;
                        do{
                                sortingOptions();

                                printf("Enter your choice : ");
                                int choiceLL = 0;
                                scanf("%d",&choiceLL);
                                option = choiceLL;

                                switch(choiceLL){
                                        case 1 : bubbleSort();
                                                 break;

                                        case 2 : selectionSort();
						 break;
 
                                        case 3 : insertionSort();
                                                 break;

                                        case 4 : break;

                                        default :
                                                printf("\033[0;31m");
                                                printf("\t--> Please Enter proper Choice <--\n");
                                                printf("\033[0;0m");
                                                break;
                                }

                         }while(option != 4);

                }
                         break;

		case 5 :
			 exitFromDS = 1;
			 printf("\t--> thanks for using Data Structure operations <--\n\n");
			 break;
	}
	} while(exitFromDS != 1);
}

