
//#include<stdio.h>
//#include<stdlib.h>

/*struct Node {
	int  data;
	struct Node* next ;
};*/
//struct Node* head = NULL;
struct Node* tail = NULL;
int chkInt(char*);
extern int error ;

/*void cllOptions(){

        printf("\n1.print Node\t2.add Node at End\t3.add Node at begining\t4.add Node at position\n");
        printf("5.deleteFirst\t6.deleteLast\t\t7.deleteAtPos\t\t8.delete All Nodes\t\n");
        printf("9.Count\t\t10.exit\t\n\n\n--> ");
}*/

struct Node* cllNewNode (){
	struct Node* node = (struct Node* ) malloc(sizeof(struct Node));
        char name[10];

	do{
                printf("Enter Data -> ");
                scanf("%s",name);

                node->data = chkInt(name);
        } while( error == 1);

	node->next = NULL;

	return node;
}

void cllPrintNode(){
	if(head == NULL){
		printf("\033[0;31m");
		printf("\t--> Your Singly Circular LinkedList is Empty <--");
		printf("\033[0;0m");
	} else{
		struct Node* temp = head;
		printf("\nNode : ");
		printf("\033[5;37m");
		do{
			if(temp->next == head)
				printf("|%d|",temp->data);
			else
				printf("|%d|-->",temp->data);
			temp = temp->next;

		} while(temp != head);
		printf("\033[0;0m");
	}
}

void cllAddAtBeg(){
	struct Node* newNode =cllNewNode(); 

	if(head == NULL){
		head = newNode;
		tail = head;
		head->next = head;
	} else{
		newNode->next = head;
		head = newNode;
		tail->next = head;
	}

	cllPrintNode();
}

void cllAddAtEnd(){
	if(head == NULL)
		cllAddAtBeg();
	else {
		struct Node* newNode = cllNewNode();
		
		tail->next = newNode;
		tail = newNode;
		tail->next = head;

		cllPrintNode();
	}
}

int cllCount(){
	int cnt = 0;

	if(head == NULL)
		return 0;

	struct Node* temp = head;

	do{
		cnt++;
		temp = temp->next;
	}while(temp != head);

	return cnt;
}

void cllAddAtPos(){
	int pos=0; 

        char name[10];

        do{
                printf("Enter pos : ");
                scanf("%s",name);

                pos = chkInt(name);
        } while(error == 1);

	if(pos <= 0){
		printf("\033[0;31m");
		printf("\t--> Our Singly Circular LinkedList start from 1 <--");
		printf("\033[0;0m");
	} else if (pos == 1)
		cllAddAtBeg();
	else if (pos>1 && pos<=cllCount()){
		int cnt=0;
		struct Node* temp    = head;
		struct Node* newNode = cllNewNode();

		while (cnt != pos-2){
			cnt++;
			temp = temp->next;
		}
		newNode->next = temp->next;
		temp->next = newNode;

		cllPrintNode();

	}else if (pos == (cllCount()+1)){
		cllAddAtEnd();
	}else if(pos > cllCount()){
		printf("\033[0;31m");
		printf("\t--> Entered position is out of range <--");
		printf("\033[0;0m");
	}
}
void cllDeleteFirst (){
	if(head == NULL){
		printf("\033[0;31m");
		printf("\t--> Singly Circular LinkedList is Already Empty <--");
		printf("\033[0;0m");
		return;
	} else {
		struct Node* temp =head;

		head = temp->next;
		free(temp);
		tail->next = head;

		if(cllCount() == 1 && head==tail && temp==head){
			head = NULL;
			tail = NULL;

			printf("\t--> Your Singly Circular LinkedList is Empty Now <--");
			return;
		}
		cllPrintNode();
	}
}
void cllDeleteLast (){
	if(head == NULL){
		printf("\033[0;31m");
		printf("\t--> Singly Circular LinkedList is Already Empty <--");
		printf("\033[0;0m");
		return;
	}
	struct Node* temp = head;

	while (temp->next != tail)
		temp = temp->next;
	tail = temp;
	temp = temp->next;
	free(temp);
	tail->next = head;
	
	if(cllCount() == 1 && temp==head && head==tail){
                        head = NULL;
                        tail = NULL;
                        printf("\t--> Your Singly Circular LinkedList is Now Empty <--");
                        return;
        }
	cllPrintNode();
}
void cllDeleteAtPos(){
	int pos=0;

        char name[10];

        do{
                printf("Enter pos : ");
                scanf("%s",name);

                pos = chkInt(name);
        } while(error == 1);

	if(pos<=0){
		printf("\033[0;31m");
		printf("\t--> Our Singly Circular LinkedList start form 1 <--");
		printf("\033[0;0m");
	} else if (pos==1)
		cllDeleteFirst();
	else if(pos>1 && pos<cllCount()){
		struct Node* temp = head;
		struct Node* dummy = NULL;
		int cnt=0;

		while(cnt != pos-2){
			temp = temp->next;
			cnt++;
		}
		
		dummy = temp->next;
		temp->next = temp->next->next;

		cllPrintNode();
	}else if(pos == cllCount())
		cllDeleteLast();
	else if(pos > cllCount()){
		printf("\033[0;31m");
		printf("\t--> Entered position is out of range <--");
		printf("\033[0;0m");
	}
}
void cllDeleteAllNodes(){
	struct Node* temp = head;

	if(head == NULL){
		printf("\033[0;31m");
		printf("\t--> Singly Circular LinkedList is already Empty <--");
		printf("\033[0;0m");
		return;
	}

	do{
		head = head->next;
		free(temp);
		temp=head;
	}while(head != tail);
	head=NULL;
	tail=head;

	printf("\t--> All nodes deleted from Singly Circular LinkedList <--");
}
void circularSinglyLinkedList(){

	head = NULL;
	tail = NULL;

	printf("\033[04;37m");
        printf("\n\t\t\t-----> ENTER YOUR CHOICE IN SINGLY CIRCULAR LINKEDLIST <-----\n");
	printf("\033[04;37m");
        int choice = 0, exit = 1;

        do{
		printf("\n\n");
                options();
		char name[10];

                do{
                        printf("Enter choice --> ");
                        scanf("%s",name);

                         choice= chkInt(name);
                } while(error == 1);

                switch(choice){
                        case 1 : cllPrintNode();
                                 break;
                        case 2 : cllAddAtEnd();
                                 break;
                        case 3 : cllAddAtBeg();
                                 break;
                        case 4 : cllAddAtPos();
                                 break;
                        case 5 : cllDeleteFirst();
                                 break;
                        case 6 : cllDeleteLast();
                                 break;
                        case 7 : cllDeleteAtPos();
                                 break;
                        case 8 : cllDeleteAllNodes();
                                 break;
			case 9: printf("Count of Nodes : %d",cllCount());
                                break;
                        case 10 :exit = 0;
                                 break;
			default :
				printf("\033[0;31m");
				 printf("\t--> Enter perfect No  <--\n");
				printf("\033[0;0m");
				 break;
                }
        }while(exit);

	printf("\n\t\t--> Thanks for used Singly Circular Linked List DATA STRUCTURE <--\n");
}
/*
void main(){
	
	circularSinglyLinkedList();
}*/
