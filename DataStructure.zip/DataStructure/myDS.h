#include "singlyLinkedList.h"
#include "circularSinglyLinkedList.h"
#include "doublyLinkedList.h"
#include "doublyCircularLinkedList.h"
#include "stack.h"
#include "queue.h"
#include "bubbleSort.h"
#include "selectionSort.h"
#include "insertionSort.h"

int error=0;
int converteInInt(char*);
int chkInt(char*);

void llOptions(){
        printf("\033[0;35m");
        printf("\n--------------------------------------------------------------------------\n\t1. Singly Linked List\n");
        printf("\t2. Doubly Linked List\n\n");
        printf("\t3. Singly Circular Linked List\n");
        printf("\t4. Doubly Circular Linked List\n");
        printf("\t5. Exit\n---------------------------------------------------------------------\n\n");
        printf("\033[0;0m");
}

void sortingOptions(){

        printf("\033[0;35m");
        printf("\n--------------------------------------------------------------------------\n\t1.Bubble Sort\n");

        printf("\t2.Selection Sort\n");
        printf("\t3.Insertion Sort\n");
        printf("\t4. Exit\n---------------------------------------------------------------------\n\n");
        printf("\033[0;0m");

}
//here we first check given string are integer or not
int chkInt(char* name){

        for(int i=0; name[i] != '\0'; i++){
                if(name[i]>47 && name[i]<58 )
                        continue;
                else{
                        printf("\033[0;31m");
                        printf("\t--> please enter integer value <--\n");
                        error = 1;              // if this is not integer then loop iterates continuosly
                        printf("\033[0;0m");
                        return 0;
                }
        }
        error = 0;              // jevhaerror=1 zal tyanntr user ne correct integer takl tr code sucessfully run zala pahije mhnun =0 kely. otherwise code infinite la jail
        return converteInInt(name) ;            // if this is integer then automatically it converte in integer
}

int converteInInt (char* name){

        int num=0;

        for(int i=0; name[i] != '\0';i++ ){
                num = num*10+(name[i]-48);
        }

        return num;
}

