#include<stdio.h>

void insertionSort() {
	int size = 0;

        printf("\nEnter size of array : ");
        scanf("%d",&size);

        int arr[size];

        printf("Enter %d element : ",size);
        for(int i=0;i<size;i++)
                scanf("%d",&arr[i]);



        int len = sizeof(arr)/sizeof(arr[0]) ;


        //printf("\033[03;37m");
        printf("\n\nArray Before Sorting :\t | ");
        for(int i=0; i<len; i++)
                printf("%d | ",arr[i]);
        printf("\n");

	for(int i=0; i<len; i++){
		for(int j=i-1; j>=0 && arr[j]>temp; j--){
			arr[j+1] = arr[j];
		}
		arr[j+1] = temp;
	}

	printf("\n\nArray after Sorting :\t | ");
        for(int i=0; i<len; i++)
                printf("%d | ",arr[i]);
        printf("\n\n\n");
        //printf("\033[0;0m");
}
void main(){
	insertionSort();

}
