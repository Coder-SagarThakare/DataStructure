

#include<stdio.h>
int chkInt(char*);
extern int error ;

/*void sortingOptions(){

        printf("\033[0;33m");
        printf("\n1.Bubble Sort\t2.Selection Sort\n\n");
        printf("\033[0;0m");
}*/

void selectionSort(){

	printf("\033[04;37m");
        printf("\n\t\t\t-----> WELCOME IN SELECTION SORT <-----\n\n");
        printf("\033[0;0m");



        int size = 0;
	char name[10];

	do {
		printf("\nEnter size of array : ");
		//scanf("%d",&size);
                scanf("%s",name);

                size = chkInt(name);
        } while( error == 1);

        int arr[size];

        printf("\nEnter %d element : \n\n",size);


        for(int i=0;i<size;i++){
		char name[10];

		do{
			printf("Enter %d element : ",i+1);
			scanf("%s",name);

        	        arr[i] = chkInt(name);
	        } while( error == 1);

                //scanf("%d",&arr[i]);
	}

        int len = sizeof(arr)/sizeof(arr[0]) ;          

        printf("\033[03;37m");
        printf("\n\nArray Before Sorting :\t | ");
        for(int i=0; i<len; i++)
                printf("%d | ",arr[i]);
        printf("\n");

        // int count =0;

        for(int i=0; i<len; i++){
		//int dataMovedCnt = 0;
		for(int j=i+1;j<len; j++){

			if(arr[i] > arr[j]){
				int temp = arr[j];
				arr[j]   = arr[i];
				arr[i]    = temp;

		//		dataMovedCnt = 1;
			}
		}
		//if(dataMovedCnt == 0)		jevha 14 32 65 78 91 asa data yto tvha gndt. bcoz 14 first pos lach rahnare mg asha veli ekhi data move hot nahi.
		//	break;
	}


        printf("\n\nArray after Sorting :\t | ");
        for(int i=0; i<len; i++)
                printf("%d | ",arr[i]);
        //printf("\n\n%d\n",count);
        printf("\n\n\n");
        printf("\033[0;0m");
}
/*
void main(){
	selectionSort();
}*/
