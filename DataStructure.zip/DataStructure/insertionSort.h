#include<stdio.h>
int chkInt(char*);
extern int error ;


void insertionSort() {
        printf("\033[04;37m");
        printf("\n\t\t\t-----> WELCOME IN INSERTION SORT <-----\n\n");
        printf("\033[0;0m");


	int size = 0;
	char name[10];

	do {
		printf("\nEnter size of array : ");
		//scanf("%d",&size);
                scanf("%s",name);

                size = chkInt(name);
        } while( error == 1);

        //scanf("%d",&size);

        int arr[size];

        printf("\nEnter %d element : \n\n",size);
        for(int i=0;i<size;i++){
		char name[10];

		do{
			printf("Enter %d element : ",i+1);
			scanf("%s",name);

        	        arr[i] = chkInt(name);
	        } while( error == 1);

         //       scanf("%d",&arr[i]);
	}



        int len = sizeof(arr)/sizeof(arr[0]) ;


        printf("\033[03;37m");
        printf("\n\nArray Before Sorting :\t | ");
        for(int i=0; i<len; i++)
                printf("%d | ",arr[i]);
        printf("\n");

	int j=0;

	for(int i=0; i<len; i++){
		int temp = arr[i];
		for( j=i-1; j>=0 && arr[j]>temp; j--){
			arr[j+1] = arr[j];
		}
		arr[j+1] = temp;
	}

	printf("\n\nArray after Sorting :\t | ");
        for(int i=0; i<len; i++)
                printf("%d | ",arr[i]);
        printf("\n\n\n");
        printf("\033[0;0m");
}
/*void main(){
	insertionSort();

}*/
