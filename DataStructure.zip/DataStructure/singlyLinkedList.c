
#include<stdio.h>
#include<stdlib.h>

struct Node {
	int data;
	struct Node *next ;
};

struct Node* head = NULL;

void options(){

	printf("\n1.print Node\t2.add Node at End\t3.add Node at begining\t4.add Node at position\n");
	printf("5.deleteFirst\t6.deleteLast\t\t7.deleteAtPos\t\t8.delete All Nodes\t\n");
	printf("9.Count\t\t10.exit\t\n\n\n--> ");
}

void printNode(){
	printf("\n");
	if(head == NULL)
		printf("Node not present ");
	else {
		printf("Node : ");
		struct Node* temp = head;
		while(temp != NULL){
			if(temp->next == NULL)
				printf("|%d|",temp->data);
			else
				printf("|%d|-->",temp->data);

			temp = temp->next;
		}
	}
	printf("\n");
}
struct Node* createNewNode(){

	struct Node* node = (struct Node*) (malloc(sizeof(struct Node)));

	printf("Enter Data -> ");

	scanf("%d",&node->data);

	node->next = NULL;
	return node;
}
void addAtBeg(){

	struct Node* temp=head;
	struct Node* newNode = createNewNode();

	newNode->next = head;
	head = newNode;

	printNode();
}
void addAtEnd(){
	if(head == NULL)
		addAtBeg();
	else{
		struct Node* temp = head;

		while(temp->next != NULL){
			temp = temp->next;
		}

		temp->next = createNewNode();
		printNode();
	}
}
int count (){
	struct Node* temp = head;

	int cnt =0;
	while(temp != NULL){
		cnt++;
		temp = temp->next;
	}
	
	return cnt;
}
void addAtPos(){
	int pos=0;

	printf("Enter your position : ");
	scanf("%d",&pos);

	if(pos <= 0)
		printf("our linkedlist start from one\n");
	else if (pos == 1)
		addAtBeg();
	else if (pos >=2  && pos <= count() ){		// ithun chk kraych rahily
		// printf("in adddAtPos\n");
		struct Node* temp = head;
		int cnt=0;

		while( cnt != pos-2 ) {
			cnt++;
			temp = temp->next;
		}

		struct Node* newNode = createNewNode();

		newNode->next = temp->next ;
		temp->next = newNode ;

		printNode();
	}else if (pos == count()+1)
		addAtEnd();
	else if ( pos > count() )
		printf("entered position is out of node\n");
}
void deleteFirst() {

	if(head == NULL)
		printf("Node not present\n");
	else {
		struct Node *temp = head;

		head = temp->next ;

		free(temp);

		printNode();
	}
}
void deleteLast(){

	if(head == NULL)
		printf("Node not present\n");
	else{
		struct Node *temp = head;

		while(temp->next->next != NULL){
			temp = temp->next;
		}

		free(temp->next);
		temp->next = NULL;

		printNode();
	}
}
void deleteAtPos(){
	int pos = 0 ;
	printf("Enter pos : ");
	scanf("%d",&pos);

	if(pos <= 0)
		printf("Our Linkedlist start from 1\n");
	else if(pos == 1)
		deleteFirst();
	else if(pos >1 && pos < count()) {

		struct Node *temp = head;

		int cnt =0;
		while(pos-2 != cnt){
			cnt++;
			temp = temp->next;
		}

		struct Node *dummy = temp->next;
		temp->next = temp->next->next;
		free(dummy);

		printNode();
	}else if (pos == count()){
		deleteLast();
	}else if(pos > count())
		printf("Entered position is out of range\n");
}

void deleteAllNodes() {
	struct Node* temp = head;

	while(temp != NULL){
		struct Node* dummy = temp;

		temp = temp->next;
		free(dummy);
	}
	if(head = NULL)
		printf("Nodes not present\n");
	else
		printf("All Nodes are deleted\n");

}

void singlyLinkedList(){

	printf("\n\t\t\t-----> ENTER YOUR CHOICE IN SINGLY LINKED LIST<-----\n\n");
	int choice = 0, exit = 1;

	do{
		options();
		scanf("%d",&choice);

		switch(choice){
			case 1 : printNode();
				 break;
			case 2 : addAtEnd();
				 break;
			case 3 : addAtBeg();
				 break;
			case 4 : addAtPos();
				 break;
			case 5 : deleteFirst();
				 break;
			case 6 : deleteLast();
				 break;
			case 7 : deleteAtPos();
				 break;
			case 9: printf("%d",count());
				break;
			case 8 : deleteAllNodes();
				 break;
			case 10 : 
				exit = 0;	  
				 break;
			default :printf("--> Enter perfect No  <--\n");
		}
	}while(exit);

	printf("out of switch\n");
}
/*
void main(){

	singlyLinkedList();
}
*/
