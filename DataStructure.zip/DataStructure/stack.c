
#include<stdio.h>
#include<stdlib.h>

/*struct Node {
	int data;
	struct Node* next;
};

struct Node* head = NULL;*/

struct Node* top = NULL;
int dummy =0;			// pop() hotana head null aahe ka evdh check krnyasathi yacha use aahe fkt
void stackOptions (){
	printf("\033[0;33m");
        printf("\n\n\t1.PrintStack\t2.Push\t\t3.Pop\n\t4.isEmpty\t5.stackCount\t6.exit\n");       
	printf("\033[0;0m");
}

void printStack(){

	if(head == NULL){
		printf("\033[0;31m");
		printf("\n\t--> Your Stack is Empty <--\n");
		printf("\033[0;0m");
		return;
	}
	struct Node* temp = head;

	printf("\033[5;37m");
	printf("\nStack : \n");
	while(top != head){
		while(temp->next != top)
			temp = temp->next;
	
		printf("\t|%5d |\n\t|------|\n",temp->next->data);

		top = temp;
		temp = head;
	}

	printf("\t|%5d |\n\t'------'\n",head->data);
	printf("\033[0;0m");
	while(top->next != NULL)
		top = top->next;
}

struct Node* createNode(){

	struct Node* node = malloc(sizeof(struct Node));
	
	printf("Enter data : ");
	scanf("%d",&node->data);

	node->next = NULL;

	return node;
}

void push(){
	struct Node* newNode = createNode();

	if(head == NULL ){
		top = newNode;
		head = top;
	}else{
		//while(tail->next != NULL)
		//	tail = tail->next;

		top->next = newNode;
		top = newNode;
	}

	printStack();
}
int pop(){			// pop hoty but popped element proper bhetat nahiye
	int retValue = 0 ;

	if(head == NULL){
		dummy = 1;
		return -1;
	}else if(head == top) {		// ekch node ahe ka he check krnyasathi ha else
		retValue = head->data;
		free(head);
		head = NULL;
		return retValue;
	}	

	struct Node* temp = head;
	while(temp->next != top)
		temp = temp->next;
	retValue = top->data;
	
	free(top);
	top = temp;
	temp->next = NULL;

	return retValue;
}
int countStack(){
        int cnt=0;

        struct Node* temp = head;
        while(temp != NULL){
                temp = temp->next;
                cnt++;
        }

        return cnt;
}
int isEmpty (){

	if(head == NULL)
		return 1 ;
	else
		return 0 ;
}

void stack(){
	int exit = 0;
	printf("\033[04;37m");
	printf("\n\t\t---> ENTER YOUR CHOICE IN STACK <--\n\n");
	printf("\033[0;0m");

	do{
		printf("\n--------------------------------------------------------------");
		stackOptions();	

		int choice=0;

		printf("\n--> Enter Choice : ");
		scanf("%d",&choice);

		if(choice == 1)
			printStack();
		else if (choice == 2)
			push();
		else if(choice == 3){
			int data = pop();

			if(data==-1 && dummy == 1){
				printf("\033[0;31m");
				printf("\n\t--> Stack is already Empty <--\n");
				dummy = 0;
				printf("\033[0;0m");
			} else {
				printf("\033[04;37m");
				printf("Popped Data : %d\n",data); 
				printf("\033[0;0m");

				if(head==NULL)
					printf("\n\t--> Your stackframe is empty from now <--\n");
				else
					printStack();
			}
		} else if(choice == 4){
			if(isEmpty()){
				printf("\t--> Stack is Empty <--");
			} else {
				printf("\t--> Stack is not Empty <--");
			}

			printf("\n");
		}
		else if(choice == 5){
			printf("\033[0;37m");
			printf("\nStack Count : %d\n",countStack());
			printf("\033[0;0m");
		} else if(choice == 6){
			exit = 1;
		} else{
			printf("\033[0;31m");
			printf("\n\t--> Enter perfect choice <--\n");
			printf("\033[0;0m");
		}

	}while(!exit);
	printf("\n\t--> Thanks for using stack <--\n\n");
}

/*void main(){
        stack();
}*/
