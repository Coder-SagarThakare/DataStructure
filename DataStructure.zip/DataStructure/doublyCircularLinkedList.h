
//#include<stdio.h>
//#include<stdlib.h>

/*struct NodeD {
	struct NodeD* prev;
	int data;
	struct NodeD* next;
};
struct NodeD* headD = NULL;*/
struct NodeD* tailD = NULL;
int chkInt(char*);
extern int error ;

/*struct NodeD* dllCreateNewNode(){
	struct NodeD* node = malloc(sizeof(struct NodeD));
	node->prev = NULL;
	
	printf("Enter data : ");
	scanf("%d",&node->data);

	node->next = NULL;

	return node;
}
*/

void dcllPrintNode(){
	struct NodeD* temp = headD;
	if(headD == NULL){
		printf("\033[0;31m");
		printf("\t--> Your Doubly Circular LinkedList is Empty <--");
		printf("\033[0;0m");
		return ;
	}

	printf("Node : ");
	printf("\033[5;37m");

	do{

		if(temp->next != headD)
			printf("|%d|-->",temp->data);
		else
			printf("|%d|",temp->data);

		temp = temp->next;

	}while(temp != headD);
	printf("\033[0;0m");

}

void dcllAddAtBeg(){
	struct NodeD* newNode = dllCreateNewNode();

	if(headD == NULL){
		headD = newNode;
		tailD = headD;

		headD->next = tailD;
		headD->prev = headD;
	}else {
		newNode->prev = tailD;
		newNode->next = headD;
		headD->prev = newNode;
		tailD->next = newNode;

		headD = newNode;
	}
	dcllPrintNode();
}

void dcllAddAtEnd (){
	if(headD == NULL)
		dcllAddAtBeg();
	else{
		struct NodeD* newNode = dllCreateNewNode();

		tailD->next = newNode;
		newNode->prev = tailD;

		newNode->next = headD;
		headD ->prev = newNode;

		tailD = newNode;
		dcllPrintNode();
	}
}

int dcllCount(){

	int cnt=0;
	if(headD == NULL)
		return cnt;

	struct NodeD* temp = headD;
	do{
		cnt++;
		temp = temp->next;
	}while(temp != headD);

	return cnt;
}
void dcllAddAtPos(){
	int pos =0;

	char name[10];

        do{
                printf("Enter pos : ");
                scanf("%s",name);

                pos = chkInt(name);
        } while(error == 1);


	if(pos<=0){
		printf("\033[0;31m");
		printf("\t--> Our Doubly Circular LinkedList start from 1 <--");
		printf("\033[0;0m");
	}
	else if (pos == 1)
		dcllAddAtBeg();
	else if(pos>1 && pos<=dcllCount()){
		struct NodeD* temp = headD;
		struct NodeD* newNode = dllCreateNewNode();
		int cnt=0;
		
		while (cnt != pos-2){
			temp = temp->next;
			cnt++;
		}
		newNode -> prev = temp;
		newNode -> next = temp->next;
		temp->next->prev = newNode;
		temp ->next = newNode ;

		dcllPrintNode();

	}else if(pos == (dcllCount()+1))
		dcllAddAtEnd();
	else {
		printf("\033[0;31m");
		printf("\t--> Entered position is out of range <--");
		printf("\033[0;0m");
	}
}	
void dcllDeleteFirst(){
	struct NodeD* temp = headD;

	if (headD == NULL){
		printf("\033[0;31m");
		printf("\t--> Your Doubly Circular LinkedLis is already Empty <--");
		printf("\033[0;0m");
		return ;
	}else if(headD->next == headD){
		free(temp);

		printf("\t--> Your Doubly Circular LinkedList is Now Empty <--");

		headD = NULL;
		tailD = NULL;
	}else {

		headD = headD->next;
		headD->prev = tailD;
		tailD->next = headD;
		free(temp);
		dcllPrintNode();
	}
}
void dcllDeleteLast(){
	if(headD == NULL){
		printf("\033[0;31m");
		printf("\t--> Your Doubly Circular LinkedList is already Empty <--");
		printf("\033[0;0m");
		return;
	}else if (headD->next == headD){

		printf("\t--> Your Doubly Circular LinkedList is Now Empty <--");

		free(headD);
		headD = NULL;
		tailD = NULL;

	}else {

		struct NodeD* temp = tailD;

		tailD = tailD->prev;

		tailD->next = headD;
		headD->prev = tailD;
		free(temp);
		dcllPrintNode();
	}
}

void dcllDeleteAtPos(){
	int pos=0;

	char name[10];

        do{
                printf("Enter pos : ");
                scanf("%s",name);

                pos = chkInt(name);
        } while(error == 1);


	if(pos <= 0){
		printf("\033[0;31m");
		printf("\t--> Our Doubly Circular LinkedList start from 1 <--");
		printf("\033[0;0m");
	}
	else if(pos ==1)
		dcllDeleteFirst();
	else if (pos>1 && pos<dcllCount()){
		struct NodeD* temp = headD;
		int cnt =0;

		while(cnt != pos-2){
			cnt++;
			temp = temp->next;
		}
		
		struct NodeD* dummy = temp->next;

		temp->next = temp->next->next;
		temp->next->prev = temp;
		
		free(dummy);

		dcllPrintNode();
	}else if(pos == dcllCount())
		dcllDeleteLast();
	else{
		printf("\033[0;31m");
		printf("\t--> Entered Position is out of range <--");

		printf("\033[0;0m");
	}
}
void dcllDeleteAllNodes(){

	if(headD == NULL){
		printf("\033[0;31m");
		printf("\t--> Your Doubly Circular LinkedList is already Empty -->");
		printf("\033[0;0m");
		return;
	}

	struct NodeD* temp = headD;

	do{
		temp = headD;
		headD = headD->next;

		free(temp);
	}while(headD != tailD );

	//free(headD);

	headD = NULL;
	tailD = NULL;
	
	printf("\t--> All Nodes are deleted from Doubly Circular LinkedList <--");
}

void doublyCircularLinkedList(){

	headD = NULL;
	tailD = NULL;

	printf("\033[04;37m");
        printf("\n\t\t\t-----> ENTER YOUR CHOICE IN DOUBLY CIRCULAR LINKEDLIST <-----\n\n");
	printf("\033[04;37m");

        int choice = 0, exit = 1;

        do {

		printf("\n");
                options();
                //anf("%d",&choice);
		char name[10];

                do{
                        printf("Enter choice --> ");
                        scanf("%s",name);

                         choice= chkInt(name);
                } while(error == 1);

                switch(choice){
                      
		       	case 1 : dcllPrintNode();
                                 break;
                        case 2 : dcllAddAtEnd();
                                 break;
                        case 3 : dcllAddAtBeg();
                                 break;
                        case 4 : dcllAddAtPos();
                                 break;
                        case 5 : dcllDeleteFirst();
                                 break;
                        case 6 : dcllDeleteLast();
                                 break;
                        case 7 : dcllDeleteAtPos();
                                 break;
			case 9: printf("Count of Nodes : %d",dcllCount());
                                break;
                        case 8 : dcllDeleteAllNodes();
                                 break;
                        case 10 :
                                exit = 0;
                                 break;
                        default :
				printf("\033[0;31m");
				printf("\t--> Enter perfect No  <--\n");
				printf("\033[0;0m");
				break;
                }
        }while(exit);

       printf("\n\t--> Thanks for used Doubly Circular Linked List DATA STRUCTURE <--\n");
}
/*
void main(){
	doublyCircularLinkedList();
}
*/
