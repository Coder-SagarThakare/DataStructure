
#include<stdio.h>

/*void sortingOptions(){
	
	printf("\033[0;33m");
	printf("\n1.Bubble Sort\t2.Selection Sort\n\n");
	printf("\033[0;0m");
}*/
int chkInt(char*);
extern int error ;

void bubbleSort(){

        printf("\033[04;37m");
        printf("\n\t\t\t-----> WELCOME IN BUBBLE SORT <-----\n\n");
        printf("\033[0;0m");



	int size = 0;
	char name[10];

	do {
	printf("\nEnter size of array : ");
	//scanf("%d",&size);
                scanf("%s",name);

                size = chkInt(name);
        } while( error == 1);

	int arr[size];

	printf("\tEnter %d element \n\n ",size);

	for(int i=0;i<size;i++){
		char name[10];
		
		do{
			printf("Enter %d element : ",i+1);
			scanf("%s",name);

        	        arr[i] = chkInt(name);
	        } while( error == 1);
	}

		//scanf("%d",&arr[i]);
	


	int len = sizeof(arr)/sizeof(arr[0]) ;  	


	printf("\033[03;37m");
	printf("\n\nArray Before Sorting :\t | ");
	for(int i=0; i<len; i++)
		printf("%d | ",arr[i]);
	printf("\n");

	
//	 int count =0;

	for(int i=0; i<len; i++){
//		int dataMoved = 0;
		for(int j=0; j<len-i-1;j++){
//			count++;
			if(arr[j] > arr[j+1]){
				int temp = arr[j];
				arr[j]   = arr[j+1];
				arr[j+1]   = temp  ;

			//	dataMoved = 1 ;		// at least 1 data have swapped in this sort.
			}

		}
	//	if(dataMoved == 0)		// if data are already in sorted state then condition will be executed
		//	break;
	}
	
	

	printf("\n\nArray after Sorting :\t | ");
	for(int i=0; i<len; i++)
		printf("%d | ",arr[i]);
//	printf("\n\n%d\n",count);
	printf("\n\n\n");
	printf("\033[0;0m");

}
/*
void main(){
	bubbleSort();
}*/
