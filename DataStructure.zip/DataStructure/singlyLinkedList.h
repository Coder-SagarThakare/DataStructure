
//#include<stdio.h>
//#include<stdlib.h>
int chkInt(char*);
extern int error ;

struct Node {
	int data;
	struct Node *next ;
};

struct Node* head = NULL;

void options(){
	printf("\033[0;33m");
	printf("\n\t-----------------------------------------------------------------------\n");
	printf("\n1.print Node\t2.add Node at End\t3.add Node at begining\t4.add Node at position\n");
	printf("5.deleteFirst\t6.deleteLast\t\t7.deleteAtPos\t\t8.delete All Nodes\t\n");
	printf("9.Count\t\t10.exit\t\n\n");
	printf("\033[0;0m");
}

void printNode(){
	printf("\n");
	if(head == NULL){
		printf("\033[0;31m");
		printf("\t--> Your Singly Linked List is Empty <--");
		printf("\033[0;0m");
	}else {
		printf("Node : ");
		struct Node* temp = head;
		printf("\033[5;37m");

		while(temp != NULL){
			if(temp->next == NULL)
				printf("|%d|",temp->data);
			else
				printf("|%d|-->",temp->data);

			temp = temp->next;
		}
		        printf("\033[0;0m\n");
	}
	printf("\n");
}
struct Node* createNewNode(){

	char name[10];
	struct Node* node = (struct Node*) (malloc(sizeof(struct Node)));

	//printf("Enter Data -> ");

	do{
		printf("Enter Data -> ");
                scanf("%s",name);

                node->data = chkInt(name);
        } while( error == 1);

	//scanf("%d",&node->data);

	node->next = NULL;
	return node;
}
void addAtBeg(){

	struct Node* temp=head;
	struct Node* newNode = createNewNode();

	newNode->next = head;
	head = newNode;

	printNode();
}
void addAtEnd(){
	if(head == NULL)
		addAtBeg();
	else{
		struct Node* temp = head;

		while(temp->next != NULL){
			temp = temp->next;
		}

		temp->next = createNewNode();
		printNode();
	}
}
int count (){
	struct Node* temp = head;

	int cnt =0;
	while(temp != NULL){
		cnt++;
		temp = temp->next;
	}
	
	return cnt;
}
void addAtPos(){
	int pos=0;

	//printf("Enter position : ");
	//scanf("%d",&pos);
	char name[10];

        do{
                printf("Enter pos : ");
                scanf("%s",name);

                pos = chkInt(name);
        } while(error == 1);

	if(pos <= 0){
                printf("\033[0;31m");
		printf("\t--> Your Singly linkedlist start from 1 <--\n");
	        printf("\033[0;0m");

	}else if (pos == 1)
		addAtBeg();
	else if (pos >=2  && pos <= count() ){
		struct Node* temp = head;
		int cnt=0;

		while( cnt != pos-2 ) {
			cnt++;
			temp = temp->next;
		}

		struct Node* newNode = createNewNode();

		newNode->next = temp->next ;
		temp->next = newNode ;

		printNode();
	}else if (pos == count()+1)
		addAtEnd();
	else if ( pos > count() ){
                printf("\033[0;31m");
                printf("\t--> Entered position is out of range <--\n");
                printf("\033[0;0m");

	}
}
void deleteFirst() {

	if(head == NULL){
                printf("\033[0;31m");
		printf("\t--> Singly LinkedList is Already Empty <--\n");
		printf("\033[0;0m");

	}else {
		struct Node *temp = head;

		head = temp->next ;
		free(temp);

		if(head != NULL)
			printNode();
		else{
                        printf("\t--> Singly LinkedList is Now Empty <--\n");
		}
	}

}
void deleteLast(){

	if(head == NULL){
                printf("\033[0;31m");
		printf("\t--> Singly LinkedList is Already Empty <--\n");
		printf("\033[0;0m");	
	} else if(head->next == NULL){

		printf("\t--> Singly LinkedList is Now Empty Now <--\n");
		head = NULL;
	}else{
		struct Node *temp = head;

		while(temp->next->next != NULL){
			temp = temp->next;
		}

		free(temp->next);
		temp->next = NULL;

		printNode();
	}
}

void deleteAtPos(){
	int pos = 0 ;

	//printf("Enter pos : ");
	//scanf("%d",&pos);
	 char name[10];

        do{
		printf("Enter pos : ");
                scanf("%s",name);

                pos = chkInt(name);
        } while(error == 1);


	if(pos <= 0){
                printf("\033[0;31m");
		printf("\t--> Our Singly Linkedlist start from 1 <--\n");
		printf("\033[0;0m");
	}else if(pos == 1)
		deleteFirst();
	else if(pos >1 && pos < count()) {

		struct Node *temp = head;

		int cnt =0;
		while(pos-2 != cnt){
			cnt++;
			temp = temp->next;
		}

		struct Node *dummy = temp->next;
		temp->next = temp->next->next;
		free(dummy);

		printNode();
	}else if (pos == count()){
		deleteLast();
	}else if(pos > count()){
                printf("\033[0;31m");
		printf("\t--> Entered position is out of range <--\n");
		printf("\033[0;0m");
	}
}

void deleteAllNodes() {
	if(head == NULL){
                printf("\033[0;31m");
                printf("\t--> Your Singly LinkedList is already Empty <--\n");
		printf("\033[0;0m");
		return;
	}

	struct Node* temp = head;
	while(temp != NULL){
		struct Node* dummy = temp;

		temp = temp->next;
		free(dummy);
	}
	head = temp;
	printf("\t--> All nodes deleted from Singly Likedlist <--\n");
}

void singlyLinkedList(){

	head = NULL;

        printf("\033[04;37m");
	printf("\n\t\t\t-----> ENTER YOUR CHOICE IN SINGLY LINKEDLIST <-----\n\n");
        printf("\033[04;37m");

	int choice = 0, exit = 1;

	do{
		options();
		char name[10];

        	do{
			printf("Enter choice --> ");
                	scanf("%s",name);

               		 choice= chkInt(name);
	        } while(error == 1);

		//scanf("%d",&choice);

		switch(choice){
			case 1 : printNode();
				 break;
			case 2 : addAtEnd();
				 break;
			case 3 : addAtBeg();
				 break;
			case 4 : addAtPos();
				 break;
			case 5 : deleteFirst();
				 break;
			case 6 : deleteLast();
				 break;
			case 7 : deleteAtPos();
				 break;
			case 9: printf("\nCount of Nodes : %d\n",count());
				break;
			case 8 : deleteAllNodes();
				 break;
			case 10 : 
				exit = 0;	  
				 break;
			default :
                		printf("\033[0;31m");
				printf("\t--> Enter perfect Choice <--\n");	
                		printf("\033[0;0m");
				break;
		}
	}while(exit);

	printf("\n\t\t-->\tThanks for using Singly Linked List DATA STRUCTURE\t<--\n");
}
/*
void main(){

	singlyLinkedList();
}
*/
