
#include<stdio.h>
#include<stdlib.h>

struct NodeD {
	struct NodeD* prev;
	int data;
	struct NodeD* next;
};
struct NodeD* headD = NULL;
struct NodeD* tailD = NULL;

struct NodeD* dllCreateNewNode(){
	struct NodeD* node = malloc(sizeof(struct NodeD));
	node->prev = NULL;
	
	printf("Enter data : ");
	scanf("%d",&node->data);

	node->next = NULL;

	return node;
}
void options(){

        printf("\n1.print Node\t2.add Node at End\t3.add Node at begining\t4.add Node at position\n");
        printf("5.deleteFirst\t6.deleteLast\t\t7.deleteAtPos\t\t8.delete All Nodes\t\n");
        printf("9.Count\t\t10.exit\t\n\n\n--> ");
}

void dcllPrintNode(){
	struct NodeD* temp = headD;
	if(headD == NULL){
		printf("\t-->\tYour Doubly Circular LinkedList is Empty\t<--");
		return ;
	}

	do{
		if(temp->next != headD)
			printf("|%d|-->",temp->data);
		else
			printf("|%d|",temp->data);

		temp = temp->next;

	}while(temp != headD);
}

void dcllAddAtBeg(){
	struct NodeD* newNode = dllCreateNewNode();

	if(headD == NULL){
		headD = newNode;
		tailD = headD;

		headD->next = tailD;
		headD->prev = headD;
	}else {
		newNode->prev = tailD;
		newNode->next = headD;
		headD->prev = newNode;
		tailD->next = newNode;

		headD = newNode;
	}
	dcllPrintNode();
}

void dcllAddAtEnd (){
	if(headD == NULL)
		dcllAddAtBeg();
	else{
		struct NodeD* newNode = dllCreateNewNode();

		//struct NodeD* temp = headD;

		tailD->next = newNode;
		newNode->prev = tailD;

		newNode->next = headD;
		headD ->prev = newNode;

		tailD = newNode;
		dcllPrintNode();
	}
}

int dcllCount(){

	int cnt=0;
	if(headD == NULL)
		return cnt;

	struct NodeD* temp = headD;
	do{
		cnt++;
		temp = temp->next;
	}while(temp != headD);

	return cnt;
}
void dcllAddAtPos(){
	int pos =0;

	printf("Enter position : ");
	scanf("%d",&pos);

	if(pos<=0)
		printf("\t-->\tOur Doubly Circular LinkedList start from 1\t<--");
	else if (pos == 1)
		dcllAddAtBeg();
	else if(pos>1 && pos<=dcllCount()){
		struct NodeD* temp = headD;
		struct NodeD* newNode = dllCreateNewNode();
		int cnt=0;
		
		while (cnt != pos-2){
			temp = temp->next;
			cnt++;
		}
		newNode -> prev = temp;
		newNode -> next = temp->next;
		temp->next->prev = newNode;
		temp ->next = newNode ;

		dcllPrintNode();

	}else if(pos == (dcllCount()+1))
		dcllAddAtEnd();
	else 
		printf("\t-->Entered position is out of range\t<--");
}
void dcllDeleteFirst(){
	struct NodeD* temp = headD;

	if (headD == NULL){
		printf("\t-->\tYour Doubly Circular LinkedLis is already Empty\t<--");
		return ;
	}else if(headD->next == headD){
		free(temp);
		printf("\t-->\tYour Doubly Circular LinkedList is Now Empty \t<--");
		headD = NULL;
		tailD = NULL;
	}else {

		headD = headD->next;
		headD->prev = tailD;
		tailD->next = headD;
		free(temp);
		dcllPrintNode();
	}
}
void dcllDeleteLast(){
	if(headD == NULL){
		printf("\t-->\tYour Doubly Circular LinkedList is already Empty\t-->");
		return;
	}else if (headD->next == headD){
		printf("\t-->\tYour Doubly Circular LinkedList is Now Empty\t<--");
		free(headD);
		headD = NULL;
		tailD = NULL;

	}else {

		struct NodeD* temp = tailD;

		tailD = tailD->prev;

		tailD->next = headD;
		headD->prev = tailD;
		free(temp);
		dcllPrintNode();
	}
}

void dcllDeleteAtPos(){
	int pos=0;

	printf("Enter position : ");
	scanf("%d",&pos);

	if(pos <= 0)
		printf("\t-->\tOur Doubly Circular LinkedList start from 1\t<--");
	else if(pos ==1)
		dcllDeleteFirst();
	else if (pos>1 && pos<dcllCount()){
		struct NodeD* temp = headD;
		int cnt =0;

		while(cnt != pos-2){
			cnt++;
			temp = temp->next;
		}
		
		struct NodeD* dummy = temp->next;

		temp->next = temp->next->next;
		temp->next->prev = temp;
		
		free(dummy);

		dcllPrintNode();
	}else if(pos == dcllCount())
		dcllDeleteLast();
	else
		printf("\t<--\tEntered Position is out of range\t<--");
}
void dcllDeleteAllNodes(){

	if(headD == NULL){
		printf("\t-->\tYour Doubly Circular LinkedList is already Empty\t-->");
		return;
	}

	struct NodeD* temp = headD;

	do{
		temp = headD;
		headD = headD->next;

		free(temp);
	}while(headD != tailD );

	free(headD);

	headD = NULL;
	tailD = NULL;

	printf("\t-->\tAll Nodes are deleted from Doubly Circular LinkedList\t<--");
}

void doublyCircularLinkedList(){

        printf("\n\t\t\t-----> ENTER YOUR CHOICE IN SINGLY LINKED LIST<-----\n\n");
        int choice = 0, exit = 1;

        do {

		printf("\n");
                options();
                scanf("%d",&choice);

                switch(choice){
                      
		       	case 1 : dcllPrintNode();
                                 break;
                        case 2 : dcllAddAtEnd();
                                 break;
                        case 3 : dcllAddAtBeg();
                                 break;
                        case 4 : dcllAddAtPos();
                                 break;
                        case 5 : dcllDeleteFirst();
                                 break;
                        case 6 : dcllDeleteLast();
                                 break;
                        case 7 : dcllDeleteAtPos();
                                 break;
			case 9: printf("Count : %d",dcllCount());
                                break;
                        case 8 : dcllDeleteAllNodes();
                                 break;
                        case 10 :
                                exit = 0;
                                 break;
                        default :printf("--> Enter perfect No  <--\n");
                }
        }while(exit);

        printf("out of switch DCLL\n");
}

void main(){
	doublyCircularLinkedList();
}
