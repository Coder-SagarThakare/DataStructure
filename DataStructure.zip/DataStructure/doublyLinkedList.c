
#include<stdio.h>
#include<stdlib.h>

struct NodeD {

	struct NodeD* prev;
	int data;
	struct NodeD* next;
};
struct NodeD* headD = NULL;


/*void options(){

        printf("\n\n1.print Node\t2.add Node at Beginning\t3.add Node at End\t4.add Node at position\n");
        printf("5.deleteFirst\t6.deleteLast\t\t7.deleteAtPos\t\t8.delete All Nodes\t\n");
        printf("9.Count\t\t10.exit\t\n\n\n--> ");
}*/
struct NodeD* dllCreateNewNode(){
	struct NodeD* node =(struct NodeD*) malloc(sizeof(struct NodeD));
	int data =0;

	node->prev = NULL;

	printf("--> Enter Data : ");
	scanf("%d",&node->data);

	node->next = NULL;

	return node;
}
void dllPrintNode (){
	printf("\n");

	if(headD == NULL){
		printf("\t-->\tDoubly Linked List is Empty\t<--");
		return;
	}

	printf("Node : ");
	struct NodeD* temp = headD;

	while(temp != NULL){
		if(temp->next != NULL)
			printf("|%d|-->",temp->data);
		else
			printf("|%d|",temp->data);
		temp = temp->next;
	}
//	printf("\n");
}

void dllAddAtBeg(){
	struct NodeD* newNode = dllCreateNewNode();
	
	if(headD == NULL){
		headD = newNode;
	}else {

		struct NodeD* temp = headD;
		//struct NodeD* newNode = createNewNode();

		newNode->next = headD;
		headD->prev = newNode;
		headD = newNode;
	}

	dllPrintNode();
}

void dllAddAtEnd(){
	if(headD == NULL)
		dllAddAtBeg();
	else {
		struct NodeD* temp = headD;
		struct NodeD* newNode = dllCreateNewNode();

		while(temp->next != NULL){
			temp = temp->next;
		}
		
		temp->next = newNode;
		newNode->prev = temp;

		dllPrintNode();
	}
}

int dllCount(){
	struct NodeD * temp = headD;
	int cnt=0;

	while(temp != NULL){
		cnt++;
		temp = temp->next;
	}
	return cnt;
}

void dllAddAtPos(){
	int pos =0;

	printf("Enter position : ");
	scanf("%d",&pos);
	
	if(pos <= 0)
		printf("\t-->\tDoubly Linked List Start From 1 \t<--");
	else if(pos ==1)
		dllAddAtBeg();
	else if (pos>1 && pos<=dllCount()){
		struct NodeD* temp = headD;
		struct NodeD* newNode = dllCreateNewNode();
		int cnt =0;

		while(cnt != pos-2){
			cnt++;
			temp = temp->next;
		}

		newNode->prev = temp;
		newNode->next = temp->next;
		temp->next->prev = newNode;
		temp->next = newNode;

		dllPrintNode();
	}else if (pos == (dllCount()+1))
		dllAddAtEnd();
	else 
		printf("\t-->\tEntered position is out of range\t<--");

}

void dllDeleteFirst(){

	if(headD == NULL){
		printf("\t-->\tDoubly LinkedList is Already Empty\t<--");
	}else {
		struct NodeD* temp = headD;
		headD = headD->next;
		free(temp);

		if(headD != NULL){
			headD->prev = NULL;
			dllPrintNode();
		}else 
			printf("\t-->\tDoubly Linked is Empty Now\t<--");
	}
}
void dllDeleteLast(){
	if (headD == NULL)
		printf("\t-->\tDoubly LInkedList is already Empty\t<--");
	else{
		if(headD ->next == NULL){
			free(headD);
			headD = NULL;
			printf("\t-->\tDoubly LinkedList is Empty now\t<--");
		} else {
			struct NodeD* temp = headD;

			while(temp->next->next != NULL)
				temp = temp->next;
	
				free(temp->next);
				temp->next = NULL;

				dllPrintNode();
		}
	}
}
void dllDeleteAtPos(){
	int pos=0;

	printf("Enter position : ");
	scanf("%d",&pos);

	if(pos <= 0)
		printf("\t-->\tOur Linkedlist start from 1\t<--");
	else if(pos ==1 )
		dllDeleteFirst();
	else if(pos >1 && pos<dllCount()){
		struct NodeD* temp = headD;

		int cnt=0;

		while(cnt != pos-2){
			cnt++;
			temp = temp->next;
		}

		struct NodeD* dummy = temp->next;

		temp->next = temp->next->next;
		temp->next->prev = temp;

		free(dummy);

		dllPrintNode();
	}else if (pos == dllCount())
		dllDeleteLast();
	else
		printf("\t-->\tEntered position is out of range\t<--");

}
void dllDeleteAllNodes(){
	struct NodeD* temp = headD;

	if(headD == NULL){
		printf("\t-->\tYour Doubly LinkedList is already empty\t<--");
		return;
	}
	while(headD != NULL){
		headD = headD->next;
		free(temp);
		temp = headD;
	}
	printf("\t-->\tYour Doubly Linked is Empty Now\t<--");
}

void doublyLinkedList(){

        printf("\n\t\t\t-----> ENTER YOUR CHOICE IN DOUBLY LINKED LIST<-----\n\n");
        int choice = 0, exit = 1;

        do{
                options();
                scanf("%d",&choice);

                switch(choice){
                        case 1 : dllPrintNode();
                                 break;
                        case 3 : dllAddAtEnd();
                                 break;
                        case 2 : dllAddAtBeg();
                                 break;
                        case 4 : dllAddAtPos();
                                 break;
                        case 5 : dllDeleteFirst();
                                 break;
                        case 6 : dllDeleteLast();
                                 break;
                        case 7 : dllDeleteAtPos();
                                 break;
                        case 9: printf("%d",dllCount());
                                break;
                        case 8 : dllDeleteAllNodes();
                                 break;
                        case 10 :
                                exit = 0;
                                 break;
                        default :printf("--> Enter perfect No  <--\n");
				 break;

			//printf("\n");
                }
        }while(exit);

        printf("out of switch Doubly Linked List\n");
}
/*
void main(){
	doublyLinkedList();
}*/
