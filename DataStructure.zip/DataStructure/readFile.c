#include<stdio.h>

void main (){
	
	FILE* ptr ;
	char ch;

	ptr = fopen("queue.h","r");

	do{
		ch = fgetc(ptr);
		printf("%c",ch);

	} while(ch != -1);
}
